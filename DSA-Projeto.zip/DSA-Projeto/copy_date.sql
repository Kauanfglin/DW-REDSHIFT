copy dimdate
from 's3://awsdwdsa/dimdate.json'
iam_role 'arn:aws:iam::339867195707:role/awsdwredshiftfs3'
region 'us-east-2'
json as 'auto'
