copy dimproduct
from 's3://awsdwdsa/dimproduct.csv'
iam_role 'arn:aws:iam::339867195707:role/awsdwredshiftfs3'
region 'us-east-2'
delimiter ','
